﻿namespace WaferMark
{
    partial class mainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
            this.lFoup = new System.Windows.Forms.Label();
            this.textFoupID = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Seq = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.WaferID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.bRed = new System.Windows.Forms.Button();
            this.bBlue = new System.Windows.Forms.Button();
            this.bGreen = new System.Windows.Forms.Button();
            this.bYellow = new System.Windows.Forms.Button();
            this.lWaferID = new System.Windows.Forms.Label();
            this.NewLot = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.LineCircle = new System.Windows.Forms.Button();
            this.LineRound = new System.Windows.Forms.Button();
            this.LineStr = new System.Windows.Forms.Button();
            this.Line10 = new System.Windows.Forms.Button();
            this.Line0 = new System.Windows.Forms.Button();
            this.logo = new System.Windows.Forms.PictureBox();
            this.bExit = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.bPrev = new System.Windows.Forms.Button();
            this.bNext = new System.Windows.Forms.Button();
            this.bUpload = new System.Windows.Forms.Button();
            this.bClearMap = new System.Windows.Forms.Button();
            this.bInquery = new System.Windows.Forms.Button();
            this.bSave = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lFoup
            // 
            this.lFoup.AutoSize = true;
            this.lFoup.Font = new System.Drawing.Font("微軟正黑體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lFoup.Location = new System.Drawing.Point(364, 136);
            this.lFoup.Name = "lFoup";
            this.lFoup.Size = new System.Drawing.Size(141, 47);
            this.lFoup.TabIndex = 2;
            this.lFoup.Text = "Lot ID :";
            this.lFoup.Click += new System.EventHandler(this.lFoup_Click);
            // 
            // textFoupID
            // 
            this.textFoupID.Font = new System.Drawing.Font("微軟正黑體", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.textFoupID.Location = new System.Drawing.Point(511, 136);
            this.textFoupID.Name = "textFoupID";
            this.textFoupID.Size = new System.Drawing.Size(353, 50);
            this.textFoupID.TabIndex = 3;
            this.textFoupID.TextChanged += new System.EventHandler(this.textFoupID_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeight = 30;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Seq,
            this.WaferID});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.NoMove2D;
            this.dataGridView1.Enabled = false;
            this.dataGridView1.GridColor = System.Drawing.Color.Silver;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 10;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("新細明體", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.RowTemplate.Height = 33;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(222, 856);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_RowEnter);
            // 
            // Seq
            // 
            this.Seq.HeaderText = "Seq";
            this.Seq.Name = "Seq";
            this.Seq.ReadOnly = true;
            this.Seq.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Seq.Width = 50;
            // 
            // WaferID
            // 
            this.WaferID.HeaderText = "Wafer ID";
            this.WaferID.Name = "WaferID";
            this.WaferID.ReadOnly = true;
            this.WaferID.Width = 160;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Impact", 26.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label1.Location = new System.Drawing.Point(317, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(539, 43);
            this.label1.TabIndex = 13;
            this.label1.Text = "BS Wafer Scratch Mark System V1.00";
            // 
            // bRed
            // 
            this.bRed.BackColor = System.Drawing.Color.Red;
            this.bRed.Enabled = false;
            this.bRed.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bRed.Location = new System.Drawing.Point(1405, 304);
            this.bRed.Name = "bRed";
            this.bRed.Size = new System.Drawing.Size(40, 40);
            this.bRed.TabIndex = 14;
            this.bRed.UseVisualStyleBackColor = false;
            this.bRed.Visible = false;
            this.bRed.Click += new System.EventHandler(this.bRed_Click);
            // 
            // bBlue
            // 
            this.bBlue.BackColor = System.Drawing.Color.Blue;
            this.bBlue.Enabled = false;
            this.bBlue.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bBlue.Location = new System.Drawing.Point(1445, 304);
            this.bBlue.Name = "bBlue";
            this.bBlue.Size = new System.Drawing.Size(40, 40);
            this.bBlue.TabIndex = 15;
            this.bBlue.UseVisualStyleBackColor = false;
            this.bBlue.Visible = false;
            this.bBlue.Click += new System.EventHandler(this.bBlue_Click);
            // 
            // bGreen
            // 
            this.bGreen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.bGreen.Enabled = false;
            this.bGreen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bGreen.Location = new System.Drawing.Point(1405, 339);
            this.bGreen.Name = "bGreen";
            this.bGreen.Size = new System.Drawing.Size(40, 40);
            this.bGreen.TabIndex = 16;
            this.bGreen.UseVisualStyleBackColor = false;
            this.bGreen.Visible = false;
            this.bGreen.Click += new System.EventHandler(this.bGreen_Click);
            // 
            // bYellow
            // 
            this.bYellow.BackColor = System.Drawing.Color.Yellow;
            this.bYellow.Enabled = false;
            this.bYellow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bYellow.Location = new System.Drawing.Point(1445, 339);
            this.bYellow.Name = "bYellow";
            this.bYellow.Size = new System.Drawing.Size(40, 40);
            this.bYellow.TabIndex = 17;
            this.bYellow.UseVisualStyleBackColor = false;
            this.bYellow.Visible = false;
            this.bYellow.Click += new System.EventHandler(this.bYellow_Click);
            // 
            // lWaferID
            // 
            this.lWaferID.AutoSize = true;
            this.lWaferID.BackColor = System.Drawing.Color.White;
            this.lWaferID.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lWaferID.Location = new System.Drawing.Point(375, 270);
            this.lWaferID.Name = "lWaferID";
            this.lWaferID.Size = new System.Drawing.Size(32, 31);
            this.lWaferID.TabIndex = 18;
            this.lWaferID.Text = "   ";
            // 
            // NewLot
            // 
            this.NewLot.Location = new System.Drawing.Point(877, 137);
            this.NewLot.Name = "NewLot";
            this.NewLot.Size = new System.Drawing.Size(96, 50);
            this.NewLot.TabIndex = 22;
            this.NewLot.Text = "查詢";
            this.NewLot.UseVisualStyleBackColor = true;
            this.NewLot.Click += new System.EventHandler(this.NewLot_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::WaferMark.Properties.Resources.tenor;
            this.pictureBox3.Location = new System.Drawing.Point(443, 395);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(220, 220);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 29;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // LineCircle
            // 
            this.LineCircle.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LineCircle.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LineCircle.Image = global::WaferMark.Properties.Resources.CircleD;
            this.LineCircle.Location = new System.Drawing.Point(254, 770);
            this.LineCircle.Name = "LineCircle";
            this.LineCircle.Size = new System.Drawing.Size(96, 96);
            this.LineCircle.TabIndex = 28;
            this.LineCircle.UseVisualStyleBackColor = true;
            this.LineCircle.Click += new System.EventHandler(this.LineCircle_Click);
            // 
            // LineRound
            // 
            this.LineRound.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LineRound.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LineRound.Image = global::WaferMark.Properties.Resources.RoundD;
            this.LineRound.Location = new System.Drawing.Point(254, 645);
            this.LineRound.Name = "LineRound";
            this.LineRound.Size = new System.Drawing.Size(96, 96);
            this.LineRound.TabIndex = 27;
            this.LineRound.UseVisualStyleBackColor = true;
            this.LineRound.Click += new System.EventHandler(this.LineRound_Click);
            // 
            // LineStr
            // 
            this.LineStr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.LineStr.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.LineStr.Image = global::WaferMark.Properties.Resources.Line;
            this.LineStr.Location = new System.Drawing.Point(254, 520);
            this.LineStr.Name = "LineStr";
            this.LineStr.Size = new System.Drawing.Size(96, 96);
            this.LineStr.TabIndex = 26;
            this.LineStr.UseVisualStyleBackColor = true;
            this.LineStr.Click += new System.EventHandler(this.LineStr_Click);
            // 
            // Line10
            // 
            this.Line10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Line10.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Line10.Image = global::WaferMark.Properties.Resources.Line10;
            this.Line10.Location = new System.Drawing.Point(254, 395);
            this.Line10.Name = "Line10";
            this.Line10.Size = new System.Drawing.Size(96, 96);
            this.Line10.TabIndex = 25;
            this.Line10.UseVisualStyleBackColor = true;
            this.Line10.Click += new System.EventHandler(this.Line10_Click);
            // 
            // Line0
            // 
            this.Line0.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.Line0.Font = new System.Drawing.Font("新細明體", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Line0.Image = global::WaferMark.Properties.Resources.Line0D;
            this.Line0.Location = new System.Drawing.Point(254, 270);
            this.Line0.Name = "Line0";
            this.Line0.Size = new System.Drawing.Size(96, 96);
            this.Line0.TabIndex = 24;
            this.Line0.UseVisualStyleBackColor = true;
            this.Line0.Click += new System.EventHandler(this.Line0_Click);
            // 
            // logo
            // 
            this.logo.Image = global::WaferMark.Properties.Resources.chip;
            this.logo.InitialImage = global::WaferMark.Properties.Resources.chip;
            this.logo.Location = new System.Drawing.Point(254, 12);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(71, 69);
            this.logo.TabIndex = 12;
            this.logo.TabStop = false;
            // 
            // bExit
            // 
            this.bExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bExit.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bExit.Image = global::WaferMark.Properties.Resources.close;
            this.bExit.Location = new System.Drawing.Point(994, 270);
            this.bExit.Name = "bExit";
            this.bExit.Size = new System.Drawing.Size(96, 96);
            this.bExit.TabIndex = 21;
            this.bExit.UseVisualStyleBackColor = true;
            this.bExit.Click += new System.EventHandler(this.bExit_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = global::WaferMark.Properties.Resources.PSMCLogo_641;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(1613, 44);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(64, 42);
            this.pictureBox2.TabIndex = 19;
            this.pictureBox2.TabStop = false;
            // 
            // bPrev
            // 
            this.bPrev.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bPrev.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bPrev.Image = global::WaferMark.Properties.Resources.up_chevron__1_;
            this.bPrev.Location = new System.Drawing.Point(994, 645);
            this.bPrev.Name = "bPrev";
            this.bPrev.Size = new System.Drawing.Size(96, 96);
            this.bPrev.TabIndex = 10;
            this.bPrev.UseVisualStyleBackColor = true;
            this.bPrev.Click += new System.EventHandler(this.bPrev_Click);
            // 
            // bNext
            // 
            this.bNext.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bNext.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bNext.Image = global::WaferMark.Properties.Resources.down_chevron__1_;
            this.bNext.Location = new System.Drawing.Point(994, 770);
            this.bNext.Name = "bNext";
            this.bNext.Size = new System.Drawing.Size(96, 96);
            this.bNext.TabIndex = 9;
            this.bNext.UseVisualStyleBackColor = true;
            this.bNext.Click += new System.EventHandler(this.bNext_Click);
            // 
            // bUpload
            // 
            this.bUpload.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bUpload.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bUpload.Image = global::WaferMark.Properties.Resources.cloud__1_;
            this.bUpload.Location = new System.Drawing.Point(994, 520);
            this.bUpload.Name = "bUpload";
            this.bUpload.Size = new System.Drawing.Size(96, 96);
            this.bUpload.TabIndex = 8;
            this.bUpload.UseVisualStyleBackColor = true;
            this.bUpload.Click += new System.EventHandler(this.bUpload_Click);
            // 
            // bClearMap
            // 
            this.bClearMap.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bClearMap.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bClearMap.Image = global::WaferMark.Properties.Resources.eraser;
            this.bClearMap.Location = new System.Drawing.Point(994, 395);
            this.bClearMap.Name = "bClearMap";
            this.bClearMap.Size = new System.Drawing.Size(96, 96);
            this.bClearMap.TabIndex = 6;
            this.bClearMap.UseVisualStyleBackColor = true;
            this.bClearMap.Click += new System.EventHandler(this.bClearMap_Click);
            // 
            // bInquery
            // 
            this.bInquery.BackColor = System.Drawing.Color.Transparent;
            this.bInquery.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.bInquery.Enabled = false;
            this.bInquery.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.bInquery.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bInquery.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bInquery.Image = global::WaferMark.Properties.Resources.loupe;
            this.bInquery.Location = new System.Drawing.Point(1405, 146);
            this.bInquery.Name = "bInquery";
            this.bInquery.Size = new System.Drawing.Size(60, 50);
            this.bInquery.TabIndex = 4;
            this.bInquery.UseVisualStyleBackColor = false;
            this.bInquery.Click += new System.EventHandler(this.bInquery_Click);
            // 
            // bSave
            // 
            this.bSave.Enabled = false;
            this.bSave.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.bSave.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.bSave.Image = global::WaferMark.Properties.Resources.floppy_disk;
            this.bSave.Location = new System.Drawing.Point(1405, 202);
            this.bSave.Name = "bSave";
            this.bSave.Size = new System.Drawing.Size(96, 96);
            this.bSave.TabIndex = 1;
            this.bSave.UseVisualStyleBackColor = true;
            this.bSave.Click += new System.EventHandler(this.bSave_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Enabled = false;
            this.pictureBox1.InitialImage = global::WaferMark.Properties.Resources.PSMCLogo_641;
            this.pictureBox1.Location = new System.Drawing.Point(373, 269);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 600);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseDown);
            this.pictureBox1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseMove);
            this.pictureBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox1_MouseUp);
            // 
            // mainForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.ClientSize = new System.Drawing.Size(1107, 880);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.LineCircle);
            this.Controls.Add(this.LineRound);
            this.Controls.Add(this.LineStr);
            this.Controls.Add(this.Line10);
            this.Controls.Add(this.Line0);
            this.Controls.Add(this.NewLot);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.logo);
            this.Controls.Add(this.bExit);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.lWaferID);
            this.Controls.Add(this.bYellow);
            this.Controls.Add(this.bGreen);
            this.Controls.Add(this.bBlue);
            this.Controls.Add(this.bRed);
            this.Controls.Add(this.bPrev);
            this.Controls.Add(this.bNext);
            this.Controls.Add(this.bUpload);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.bClearMap);
            this.Controls.Add(this.bInquery);
            this.Controls.Add(this.textFoupID);
            this.Controls.Add(this.lFoup);
            this.Controls.Add(this.bSave);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("新細明體", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "mainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Wafer Mark System v0.1";
            this.Load += new System.EventHandler(this.mainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.logo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bSave;
        private System.Windows.Forms.Label lFoup;
        private System.Windows.Forms.TextBox textFoupID;
        private System.Windows.Forms.Button bInquery;
        private System.Windows.Forms.Button bClearMap;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button bUpload;
        private System.Windows.Forms.Button bNext;
        private System.Windows.Forms.Button bPrev;
        private System.Windows.Forms.PictureBox logo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bRed;
        private System.Windows.Forms.Button bBlue;
        private System.Windows.Forms.Button bGreen;
        private System.Windows.Forms.Button bYellow;
        private System.Windows.Forms.Label lWaferID;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button bExit;
        private System.Windows.Forms.Button NewLot;
        private System.Windows.Forms.DataGridViewTextBoxColumn Seq;
        private System.Windows.Forms.DataGridViewTextBoxColumn WaferID;
        private System.Windows.Forms.Button Line0;
        private System.Windows.Forms.Button Line10;
        private System.Windows.Forms.Button LineStr;
        private System.Windows.Forms.Button LineRound;
        private System.Windows.Forms.Button LineCircle;
        private System.Windows.Forms.PictureBox pictureBox3;
    }
}

