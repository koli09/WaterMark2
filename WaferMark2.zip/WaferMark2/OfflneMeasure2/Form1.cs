﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Compression;
using System.Threading;
using System.Data.OleDb;
using FtpLib;

namespace WaferMark
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        int MaxMarkCount = 255;
        int MarkIndex = 0;
        int PenPoint = 2;
        int origx, origy;
        int endx, endy;
        string Cooodinate = "";
        string Length = "";
        string PenType = "直線";
        string DrawPath = "temp";
        string ZipPath = "zip";
        string CurrentFoupID = "BTTEST001";
        string TIMESTRING = "";
        string LOTSTRING = "";
        string CHIPBODYSTRING = "";
        string WAFERSTRING = "";
        string CSVHEADER = "Fab,Customer,Chipbody,Lot,Wafer,Thickness,Type,Length,Coordinate,Time";
        string CSVTIME = "";
        string[] CSVSTRING;

        string FTP_IP = "172.22.242.247";
        string FTP_User = "isilon_PH94_01";
        string FTP_Pwd = "isilon_PH94_01";
        string FTP_Path = "/Original/";

        Bitmap bmp;
        
        int oldx, oldy;
        int penPoint;
        int image_size = 600;
        Color penColor;
        Graphics g,g4;
        Pen pen;

        DataTable oWafers;

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            oldx = e.X; oldy = e.Y;
            origx = e.X; origy = e.Y;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Left)
                {
                    if (penColor == Color.Black)
                        penColor = Color.Blue;
                    //penPoint = 10;
                    pen = new Pen(penColor, PenPoint);
                    g = Graphics.FromImage(bmp);
                    g.DrawLine(pen, oldx, oldy, e.X, e.Y);
                    pictureBox1.Image = bmp;
                    oldx = e.X;
                    oldy = e.Y;
                    if ((e.X > 0) && (e.X < 600) && (e.Y > 0) && (e.Y < 600))
                    {
                        endx = e.X;
                        endy = e.Y;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("pictureBox1_MouseMove:\n" + ex.ToString(), "錯誤");
            }
        }

        private void bSave_Click(object sender, EventArgs e)
        {
            try
            {
                string sFileName = CurrentFoupID + "_" + "S" + dataGridView1.CurrentRow.Cells[0].Value.ToString() + "_" + dataGridView1.CurrentRow.Cells[2].Value.ToString();
                bmp.Save(DrawPath + "\\" + sFileName + ".bmp");
            }
            catch (Exception ex)
            {
                MessageBox.Show("bSave_Click:\n" + ex.ToString(), "錯誤");
            }
        }

        private void bInquery_Click(object sender, EventArgs e)
        {

            try
            {
                if (textFoupID.Text.Trim().Length < 7)
                {
                    MessageBox.Show("輸入 FoupID 小於 8 碼,請確認.", "錯誤");
                    return;
                }
                dataGridView1.Enabled = false;
                dataGridView1.Rows.Clear();
                for (int i = 0; i < 25; i++)
                    dataGridView1.Rows.Add(new Object[] { (i + 1).ToString("D2"), "MAA001.000", "MAA001-" + (i + 1).ToString("D2"), "YGSJGHWUGSHYW" + (i + 1).ToString("D2") });

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (dataGridView1.Rows[i].Cells[2].Value.ToString().Length > 0)
                    {
                        dataGridView1.Rows[i].Selected = true;
                        dataGridView1.CurrentCell = dataGridView1.Rows[i].Cells[0];
                        lWaferID.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
                        break;
                    }
                }

                dataGridView1.Enabled = true;
                pictureBox1.Enabled = true;
                CurrentFoupID = (this.textFoupID.Text.Trim().Length > 0 ? this.textFoupID.Text.Trim() : CurrentFoupID);
                DrawWafer(dataGridView1.CurrentRow.Index);
            }
            catch (Exception ex)
            {
                MessageBox.Show("bInquery_Click:\n" + ex.ToString(), "錯誤");
            }
        }
        private void CleanSampleLine(int index)
        {

        }

        private void dataGridView1_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (!dataGridView1.Enabled)
                    return;

                //int itest = dataGridView1.SelectedRows[0].Index;
                if (dataGridView1.CurrentRow.Index == e.RowIndex)
                    return;

                //save previous slot image
                DrawWaferClockLine(Color.Gold);//clean sanple line
                string sOldFileName = LOTSTRING + "_" + dataGridView1.CurrentRow.Cells[1].Value.ToString() + "_" + TIMESTRING;
                bmp.Save(DrawPath + "\\" + sOldFileName + ".bmp");//save wafer map

                //process new slot image
                DrawWafer(e.RowIndex);
                lWaferID.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();

                DrawWaferClockLine(Color.Black);//redraw sample line
            }
            catch (Exception ex)
            {
                MessageBox.Show("dataGridView1_RowEnter:\n" + ex.ToString(), "錯誤");
            }
        }

        private void bClearMap_Click(object sender, EventArgs e)
        {
            DrawWafer(-1);
            string sOldFileName = LOTSTRING + "_" + dataGridView1.SelectedRows[0].Cells[1].Value.ToString() + "_" + TIMESTRING;
            bmp.Save(DrawPath + "\\" + sOldFileName + ".bmp");
            for (int i = 0; i < MaxMarkCount; i++)
            {
                if (CSVSTRING[i] == null)
                    continue;
                if (CSVSTRING[i].IndexOf(dataGridView1.SelectedRows[0].Cells[1].Value.ToString()) > 0)
                    CSVSTRING[i] = "";

            }
        }

        private void bNext_Click(object sender, EventArgs e)
        {
            try
            {
                if (!dataGridView1.Enabled)
                    return;
                if (dataGridView1.SelectedRows[0].Index >= dataGridView1.Rows.Count - 1)
                    return;

                DrawWaferClockLine(Color.Gold);//clean sanple line
                string sOldFileName = LOTSTRING + "_" + dataGridView1.CurrentRow.Cells[1].Value.ToString() + "_" + TIMESTRING;
                bmp.Save(DrawPath + "\\" + sOldFileName + ".bmp");

                int iSelect = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows[iSelect + 1].Selected = true;
                dataGridView1.CurrentCell = dataGridView1.Rows[iSelect + 1].Cells[0];
                DrawWafer(dataGridView1.SelectedRows[0].Index);
            }
            catch (Exception ex)
            {
                MessageBox.Show("bNext_Click:\n" + ex.ToString(), "錯誤");
            }
        }

        private void mainForm_Load(object sender, EventArgs e)
        {
            //init
            if (System.IO.Directory.Exists(DrawPath) == false)
                System.IO.Directory.CreateDirectory(DrawPath);

            string[] Files = System.IO.Directory.GetFiles(DrawPath);
            foreach(string File in Files)
                System.IO.File.Delete(File);

            if (System.IO.Directory.Exists(ZipPath) == false)
                System.IO.Directory.CreateDirectory(ZipPath);

            string[] ZipFiles = System.IO.Directory.GetFiles(ZipPath);
            foreach (string File in ZipFiles)
                System.IO.File.Delete(File);

            for (int i = 0; i < 25; i++)
                dataGridView1.Rows.Add(new Object[] { (i + 1).ToString("D2"), "", "", "" });

            DrawWafer(-1);
            DisableAll();
        }

        private void bPrev_Click(object sender, EventArgs e)
        {
            try
            {
                if (!dataGridView1.Enabled)
                    return;
                if (dataGridView1.SelectedRows[0].Index == 0)
                    return;

                DrawWaferClockLine(Color.Gold);//clean sanple line
                string sOldFileName = LOTSTRING + "_" + dataGridView1.CurrentRow.Cells[1].Value.ToString() + "_" + TIMESTRING;
                bmp.Save(DrawPath + "\\" + sOldFileName + ".bmp");

                int iSelect = dataGridView1.SelectedRows[0].Index;
                dataGridView1.Rows[iSelect - 1].Selected = true;
                dataGridView1.CurrentCell = dataGridView1.Rows[iSelect - 1].Cells[0];
                DrawWafer(dataGridView1.SelectedRows[0].Index);
            }
            catch (Exception ex)
            {
                MessageBox.Show("bPrev_Click:\n" + ex.ToString(), "錯誤");
            }
        }

        private void bRed_Click(object sender, EventArgs e)
        {
            penColor = Color.Red;
        }

        private void bBlue_Click(object sender, EventArgs e)
        {
            penColor = Color.Blue;
        }

        private void bGreen_Click(object sender, EventArgs e)
        {
            penColor = Color.Green;
        }

        private void bYellow_Click(object sender, EventArgs e)
        {
            penColor = Color.Yellow;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void bExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void DisableAll()
        {
            dataGridView1.Enabled = false;
            Line0.Enabled = false;
            Line10.Enabled = false;
            LineStr.Enabled = false;
            LineRound.Enabled = false;
            LineCircle.Enabled = false;
            pictureBox1.Enabled = false;
            bExit.Enabled = false;
            bClearMap.Enabled = false;
            bUpload.Enabled = false;
            bPrev.Enabled = false;
            bNext.Enabled = false;
        }
        private void Enable()
        {
            dataGridView1.Enabled = true;
            Line0.Enabled = true;
            Line10.Enabled = true;
            LineStr.Enabled = true;
            LineRound.Enabled = true;
            LineCircle.Enabled = true;
            pictureBox1.Enabled = true;
            bExit.Enabled = true;
            bClearMap.Enabled = true;
            bUpload.Enabled = true;
            bPrev.Enabled = true;
            bNext.Enabled = true;
        }
        private void RefreshDrawBuggonImg()
        {
            if (PenPoint > 5)
            {
                Line0.Image = global::WaferMark.Properties.Resources.Line0D;
                Line10.Image = global::WaferMark.Properties.Resources.Line10;
            }
            else
            {
                Line0.Image = global::WaferMark.Properties.Resources.Line0;
                Line10.Image = global::WaferMark.Properties.Resources.Line10D;
            }
            if(PenType=="直線")
            {
                LineStr.Image = global::WaferMark.Properties.Resources.Line;
                LineRound.Image = global::WaferMark.Properties.Resources.RoundD;
                LineCircle.Image = global::WaferMark.Properties.Resources.CircleD;
            }
            if (PenType == "圓弧")
            {
                LineStr.Image = global::WaferMark.Properties.Resources.LineD;
                LineRound.Image = global::WaferMark.Properties.Resources.Round;
                LineCircle.Image = global::WaferMark.Properties.Resources.CircleD;
            }
            if (PenType == "圓圈")
            {
                LineStr.Image = global::WaferMark.Properties.Resources.LineD;
                LineRound.Image = global::WaferMark.Properties.Resources.RoundD;
                LineCircle.Image = global::WaferMark.Properties.Resources.Circle1;
            }

        }

        private void NewLot_Click(object sender, EventArgs e)
        {
            try
            {
                textFoupID.Text = textFoupID.Text.Trim().ToUpper();

                if (textFoupID.Text.Length == 9)
                    textFoupID.Text = textFoupID.Text.Substring(0, 6) + "." + textFoupID.Text.Substring(6, 3);
                
                if (textFoupID.Text.Length != 10)
                {
                    MessageBox.Show("Lot ID 長度不正確: "+ textFoupID.Text, "錯誤");
                    return;
                }

                string P1_RPTDB_ConnStr = String.Format("Provider=IBMDADB2.1;Password={0};User ID={1};Data Source={2}", "itpsc", "itusr", "rptdb12a");
                string P2_RPTDB_ConnStr = String.Format("Provider=IBMDADB2.1;Password={0};User ID={1};Data Source={2}", "itpsc", "itusr", "rptdb12b");
                string P3_RPTDB_ConnStr = String.Format("Provider=IBMDADB2.1;Password={0};User ID={1};Data Source={2}", "itpsc", "itusr", "rptdb12m");

                oWafers = new DataTable();
                if (textFoupID.Text.Substring(0, 1) == "A")
                {
                    if (!Select_WAFER(ref oWafers, P1_RPTDB_ConnStr, "F2RPT", textFoupID.Text))
                    {
                        //MessageBox.Show("LotID: " + textFoupID.Text + " 找不到 Wafer 資訊.", "錯誤");
                        return;
                    }
                }
                else if (textFoupID.Text.Substring(0, 1) == "B")
                {
                    if (!Select_WAFER(ref oWafers, P2_RPTDB_ConnStr, "F3RPT", textFoupID.Text))
                    {
                        //MessageBox.Show("LotID: " + textFoupID.Text + " 找不到 Wafer 資訊.", "錯誤");
                        return;
                    }
                }
                else if (textFoupID.Text.Substring(0, 1) == "M")
                {
                    if (!Select_WAFER(ref oWafers, P3_RPTDB_ConnStr, "FMRPT", textFoupID.Text))
                    {
                        //MessageBox.Show("LotID: " + textFoupID.Text + " 找不到 Wafer 資訊.", "錯誤");
                        return;
                    }
                }
                else
                {
                    MessageBox.Show("LotID: " + textFoupID.Text + " 找不到廠別資訊.", "錯誤");
                    return;
                }

                if (oWafers.Rows.Count == 0)
                {
                    MessageBox.Show("LotID: " + textFoupID.Text + " 找不到 Wafer 資訊.", "錯誤");
                    return;
                }


                TIMESTRING = DateTime.Now.ToString("yyyy_MM_dd HH_mm_ss");
                CSVTIME = DateTime.Now.ToString("yyyy/MM/dd HH:mm");
                LOTSTRING = textFoupID.Text.Substring(0, 6) + textFoupID.Text.Substring(7, 3);
                CSVSTRING = new string[MaxMarkCount];
                Enable();

                dataGridView1.Enabled = false;
                dataGridView1.Rows.Clear();
                int iw = 1;
                foreach(DataRow row in oWafers.Rows)
                {
                    string tmpWaferID = row["MTRL_ID"].ToString();
                    CHIPBODYSTRING = row["PRODSPEC_ID"].ToString();
                    dataGridView1.Rows.Add(new Object[] { (iw++).ToString("D2"), tmpWaferID });
                }
                CHIPBODYSTRING = CHIPBODYSTRING.Substring(0, CHIPBODYSTRING.IndexOf("."));
                //for (int i = 0; i < oWafers.Rows.Count; i++)
                //{
                //    DataRow oWafers_Row = oWafers.Rows[i];
                //    string sDate = oCHADVOPCTLHS_Row["DATESTRING"].ToString().Trim();
                //    int iDate = Convert.ToInt16(sDate.Substring(sDate.LastIndexOf("-") + 1, sDate.Length - sDate.LastIndexOf("-") - 1));
                //    iAOCLotDailyCount[iDate]++;
                //}

                //for (int i = 0; i < 25; i++)
                //    dataGridView1.Rows.Add(new Object[] { (i + 1).ToString("D2"), LOTSTRING.Substring(0,6)+"-" + (i + 1).ToString("D2") });
                ////dataGridView1.Rows.Add(new Object[] { (i + 1).ToString("D2"), "MAA001.000", "MAA001-" + (i + 1).ToString("D2"), "YGSJGHWUGSHYW" + (i + 1).ToString("D2") });

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    if (dataGridView1.Rows[i].Cells[1].Value.ToString().Length > 0)
                    {
                        dataGridView1.Rows[i].Selected = true;
                        dataGridView1.CurrentCell = dataGridView1.Rows[i].Cells[0];
                        lWaferID.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
                        break;
                    }
                }

                dataGridView1.Enabled = true;
                pictureBox1.Enabled = true;
                CurrentFoupID = (this.textFoupID.Text.Trim().Length > 0 ? this.textFoupID.Text.Trim() : CurrentFoupID);
                DrawWafer(dataGridView1.CurrentRow.Index);
            }
            catch (Exception ex)
            {
                MessageBox.Show("bInquery_Click:\n" + ex.ToString(), "錯誤");
            }
        }

        private void Line0_Click(object sender, EventArgs e)
        {
            PenPoint = 2;
            RefreshDrawBuggonImg();
        }

        private void Line10_Click(object sender, EventArgs e)
        {
            PenPoint = 10;
            RefreshDrawBuggonImg();
        }

        private void LineStr_Click(object sender, EventArgs e)
        {
            PenType = "直線";
            RefreshDrawBuggonImg();
        }

        private void LineRound_Click(object sender, EventArgs e)
        {
            PenType = "圓弧";
            RefreshDrawBuggonImg();
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            Cooodinate = origx + ";" + origy + ";" + endx + ";" + endy;
            Length=((Math.Sqrt(Math.Pow((endx - origx), 2) + Math.Pow((endy - origy), 2)))/20).ToString("F2");
            CSVSTRING[MarkIndex++] = "Fab" + "," + "Customer" + "," + CHIPBODYSTRING + "," + LOTSTRING + "," + lWaferID.Text + "," + (PenPoint > 5 ? "粗" : "細") + "," + PenType + "," + Length + "," + Cooodinate + "," + TIMESTRING;
        }

        private void LineCircle_Click(object sender, EventArgs e)
        {
            PenType = "圓圈";
            RefreshDrawBuggonImg();
        }

        private void textFoupID_TextChanged(object sender, EventArgs e)
        {

        }

        private void lFoup_Click(object sender, EventArgs e)
        {

        }

        private void bUpload_Click(object sender, EventArgs e)
        {
            try
            {
                pictureBox3.Visible = true;
                bUpload.Enabled = false;
                //pictureBox3.Invalidate();
                //pictureBox3.Update();
                //pictureBox3.Refresh();

                if (!dataGridView1.Enabled)
                    return;

                if (dataGridView1.SelectedRows[0].Index < 0)
                    return;

                DrawWaferClockLine(Color.Gold);//clean sanple line
                //save previous slot image
                string sOldFileName = LOTSTRING + "_" + dataGridView1.CurrentRow.Cells[1].Value.ToString() + "_" + TIMESTRING;
                bmp.Save(DrawPath + "\\" + sOldFileName + ".bmp");

                //prepare csv
                if (WriteCsv() == false)
                    return;

                ////zip file
                //ZipFile.CreateFromDirectory(DrawPath, ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip");
                //File.Copy(ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip", ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip" + ".temp");
                ////upload file

                //FTPFactory FTP = new FTPFactory();
                //FTP.setRemoteHost(FTP_IP);
                //FTP.setRemotePort(21);
                //FTP.setRemoteUser(FTP_User);
                //FTP.setRemotePass(FTP_Pwd);

                //FTP.login();
                //FTP.setBinaryMode(true);
                //FTP.chdir(FTP_Path);
                //FTP.upload( ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip" + ".temp", false);
                //FTP.renameRemoteFile("OQC_BS_Raw_" + TIMESTRING + ".zip" + ".temp", "OQC_BS_Raw_" + TIMESTRING + ".zip" );
                //FTP.close();

                //clean old map info
                
                ThreadStart myThreadStart = new ThreadStart(ZipAndPutFile);
                Thread myThread = new Thread(myThreadStart);
                myThread.Start();
                while(myThread.ThreadState!=ThreadState.Stopped)
                {
                    pictureBox3.Refresh();
                    Thread.Sleep(10);
                }

                MessageBox.Show("資料上傳完畢!");
                string[] Files = System.IO.Directory.GetFiles(DrawPath);
                foreach (string File in Files)
                    System.IO.File.Delete(File);

                string[] ZipFiles = System.IO.Directory.GetFiles(ZipPath);
                foreach (string File in ZipFiles)
                    System.IO.File.Delete(File);

                DrawWafer(-1);
                textFoupID.Clear();
                lWaferID.Text = "";
                dataGridView1.Rows.Clear();
                DisableAll();
                pictureBox3.Visible = false;
                bUpload.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("bUpload_Click:\n" + ex.ToString(), "錯誤");
                pictureBox3.Visible = false;
                bUpload.Enabled = true;
                return;
            }
        }

        private void ZipAndPutFile()
        {
            try
            {
                //zip file
                ZipFile.CreateFromDirectory(DrawPath, ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip");
                File.Copy(ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip", ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip" + ".temp");
                //upload file

                FTPFactory FTP = new FTPFactory();
                FTP.setRemoteHost(FTP_IP);
                FTP.setRemotePort(21);
                FTP.setRemoteUser(FTP_User);
                FTP.setRemotePass(FTP_Pwd);

                FTP.login();
                FTP.setBinaryMode(true);
                FTP.chdir(FTP_Path);
                FTP.upload(ZipPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".zip" + ".temp", false);
                FTP.renameRemoteFile("OQC_BS_Raw_" + TIMESTRING + ".zip" + ".temp", "OQC_BS_Raw_" + TIMESTRING + ".zip");
                FTP.close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("ZipAndPutFile:\n" + ex.ToString(), "錯誤");
                return;
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            DrawWaferClockLine(Color.Gold);
        }

        private bool WriteCsv()
        {
            try
            {
                bool CSVRecordFound = false;
                for (int i = 0; i < MaxMarkCount; i++)
                {
                    if (CSVSTRING[i] == null)
                        continue;
                    if (CSVSTRING[i].Length > 0)
                    {
                        CSVRecordFound = true;
                        break;
                    }
                }
                if (CSVRecordFound == false)
                {
                    MessageBox.Show("WriteCsv:\n" + "沒有任何的已繪製的刮傷紀錄!", "錯誤");
                    return false;
                }
                StreamWriter CSVWriter = new StreamWriter(DrawPath + "\\" + "OQC_BS_Raw_" + TIMESTRING + ".csv",false,Encoding.UTF8);
                CSVWriter.WriteLine(CSVHEADER);
                for (int i = 0; i < MaxMarkCount; i++)
                {
                    if (CSVSTRING[i] == null)
                        continue;
                    if (CSVSTRING[i].Length > 0)
                        CSVWriter.WriteLine(CSVSTRING[i]);
                }

                foreach(DataRow dr in oWafers.Rows)
                {
                    bool bWaferFound = false;
                    string tmpWaferID = dr["MTRL_ID"].ToString();
                    string tmpCSVSTRING = "Fab" + "," + "Customer" + "," + CHIPBODYSTRING + "," + LOTSTRING + "," + tmpWaferID + ",,,,," + TIMESTRING;
                    for (int i = 0; i < MaxMarkCount; i++)
                    {
                        if (CSVSTRING[i] == null)
                            continue;
                        if (CSVSTRING[i].Length > 0)
                        {
                            string[] csvline = CSVSTRING[i].Split(",".ToCharArray());
                            if(tmpWaferID== csvline[4])
                            {
                                bWaferFound = true;
                                break;
                            }
                        }
                    }
                    if (bWaferFound)
                        continue;
                    CSVWriter.WriteLine(tmpCSVSTRING);
                }

                CSVWriter.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("WriteCsv:\n" + ex.ToString(), "錯誤");
                return false;
            }
        }
        private void DrawWaferClockLine(Color inputColor)
        {
            try
            {
                penPoint = 1;
                pen = new Pen(inputColor, 1);
                g = Graphics.FromImage(bmp);

                //draw 36 block
                g.DrawLine(pen, 0, 100, 600, 100);
                g.DrawLine(pen, 0, 200, 600, 200);
                g.DrawLine(pen, 0, 300, 600, 300);
                g.DrawLine(pen, 0, 400, 600, 400);
                g.DrawLine(pen, 0, 500, 600, 500);
                g.DrawLine(pen, 100, 0, 100, 600);
                g.DrawLine(pen, 200, 0, 200, 600);
                g.DrawLine(pen, 300, 0, 300, 600);
                g.DrawLine(pen, 400, 0, 400, 600);
                g.DrawLine(pen, 500, 0, 500, 600);

                g.DrawLine(pen, 290, 300, 310, 300);
                g.DrawLine(pen, 300, 290, 300, 310);
                g.DrawLine(pen, 290, 600, 300, 580);
                g.DrawLine(pen, 310, 600, 300, 580);

                for (int i = 0; i < 10; i++)
                {
                    double radians = i * 10 * (Math.PI / 180);
                    int x = Convert.ToInt16(300 * Math.Cos(radians));
                    int y = Convert.ToInt16(300 * Math.Sin(radians));
                    int sx = Convert.ToInt16(280 * Math.Cos(radians));
                    int sy = Convert.ToInt16(280 * Math.Sin(radians));
                    //g.DrawLine(pen, 300 + x, 300 + y, 300 + sx, 300 + sy);
                    //g.DrawLine(pen, 300 - x, 300 + y, 300 - sx, 300 + sy);
                    //g.DrawLine(pen, 300 + x, 300 - y, 300 + sx, 300 - sy);
                    //g.DrawLine(pen, 300 - x, 300 - y, 300 - sx, 300 - sy);

                    g.DrawLine(pen, 300 + x, 300 + y, 300 + sx, 300 + sy);
                    g.DrawLine(pen, 300 - x, 300 + y, 300 - sx, 300 + sy);
                    g.DrawLine(pen, 300 + x, 300 - y, 300 + sx, 300 - sy);
                    g.DrawLine(pen, 300 - x, 300 - y, 300 - sx, 300 - sy);
                }
                pictureBox1.Image = bmp;
                pictureBox1.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show("DrawWaferVHLine:\n" + ex.ToString(), "錯誤");
            }
        }
        private void DrawWafer(int index)
        {
            try
            {
                if (index == -1)
                {
                    //init wafer picture at start
                    penColor = Color.Black;
                    penPoint = 1;
                    pen = new Pen(penColor, penPoint);
                    bmp = new Bitmap(image_size, image_size);
                    g = Graphics.FromImage(bmp);
                    pictureBox1.Size = new Size(image_size, image_size);
                    g.Clear(Color.White);
                    Rectangle rect = new Rectangle(0, 0, image_size - 2, image_size - 2);
                    g.FillPie(Brushes.Gold, rect, 360, 360);
                    g.DrawArc(pen, 0, 0, image_size - 2, image_size - 2, 0, 360);

                    //draw 36 block
                    g.DrawLine(pen, 0, 100, 600, 100);
                    g.DrawLine(pen, 0, 200, 600, 200);
                    g.DrawLine(pen, 0, 300, 600, 300);
                    g.DrawLine(pen, 0, 400, 600, 400);
                    g.DrawLine(pen, 0, 500, 600, 500);
                    g.DrawLine(pen, 100, 0, 100, 600);
                    g.DrawLine(pen, 200, 0, 200, 600);
                    g.DrawLine(pen, 300, 0, 300, 600);
                    g.DrawLine(pen, 400, 0, 400, 600);
                    g.DrawLine(pen, 500, 0, 500, 600);

                    //g.DrawLine(pen, 290, 300, 310, 300);
                    //g.DrawLine(pen, 300, 290, 300, 310);
                    //g.DrawLine(pen, 290, 600, 300, 580);
                    //g.DrawLine(pen, 310, 600, 300, 580);
                    //g.DrawLine(pen, 300, 0, 300, 600);
                    //g.DrawLine(pen, 0, 300, 600, 300);

                    g.DrawLine(pen, 290, 300, 310, 300);
                    g.DrawLine(pen, 300, 290, 300, 310);
                    g.DrawLine(pen, 290, 600, 300, 580);
                    g.DrawLine(pen, 310, 600, 300, 580);

                    for (int i = 0; i < 7; i++)
                    {
                        double radians = i * 15 * (Math.PI / 180);
                        int x = Convert.ToInt16(300 * Math.Cos(radians));
                        int y = Convert.ToInt16(300 * Math.Sin(radians));
                        int sx = Convert.ToInt16(280 * Math.Cos(radians));
                        int sy = Convert.ToInt16(280 * Math.Sin(radians));

                        //Pen graypen = new Pen(Color.LightGray, 2);
                        //g.DrawLine(graypen, 300 + x, 300 + y, 300, 300);
                        //g.DrawLine(graypen, 300 - x, 300 + y, 300, 300);
                        //g.DrawLine(graypen, 300 + x, 300 - y, 300, 300);
                        //g.DrawLine(graypen, 300 - x, 300 - y, 300, 300);

                        g.DrawLine(pen, 300 + x, 300 + y, 300 + sx, 300 + sy);
                        g.DrawLine(pen, 300 - x, 300 + y, 300 - sx, 300 + sy);
                        g.DrawLine(pen, 300 + x, 300 - y, 300 + sx, 300 - sy);
                        g.DrawLine(pen, 300 - x, 300 - y, 300 - sx, 300 - sy);
                    }
                    pictureBox1.Image = bmp;
                    pictureBox1.Refresh();
                 }
                else
                {
                    string sFileName = LOTSTRING + "_" + dataGridView1.SelectedRows[0].Cells[1].Value.ToString() + "_" + TIMESTRING;

                    if (System.IO.File.Exists(DrawPath + "\\" + sFileName + ".bmp"))
                    {
                        System.IO.FileStream f = new FileStream(DrawPath + "\\" + sFileName + ".bmp", FileMode.Open);
                        bmp = new Bitmap(f);
                        f.Close();
                        g = Graphics.FromImage(bmp);
                        pictureBox1.Size = new Size(image_size, image_size);
                        pictureBox1.Image = bmp;
                        pictureBox1.Refresh();
                    }
                    else
                    {
                        penColor = Color.Black;
                        penPoint = 1;
                        pen = new Pen(penColor, penPoint);
                        bmp = new Bitmap(image_size, image_size);
                        g = Graphics.FromImage(bmp);
                        pictureBox1.Size = new Size(image_size, image_size);
                        g.Clear(Color.White);
                        Rectangle rect = new Rectangle(0, 0, image_size - 2, image_size - 2);
                        g.FillPie(Brushes.Gold, rect, 360, 360);
                        g.DrawArc(pen, 0, 0, image_size - 2, image_size - 2, 0, 360);

                        //draw 36 block
                        g.DrawLine(pen, 0, 100, 600, 100);
                        g.DrawLine(pen, 0, 200, 600, 200);
                        g.DrawLine(pen, 0, 300, 600, 300);
                        g.DrawLine(pen, 0, 400, 600, 400);
                        g.DrawLine(pen, 0, 500, 600, 500);
                        g.DrawLine(pen, 100, 0, 100, 600);
                        g.DrawLine(pen, 200, 0, 200, 600);
                        g.DrawLine(pen, 300, 0, 300, 600);
                        g.DrawLine(pen, 400, 0, 400, 600);
                        g.DrawLine(pen, 500, 0, 500, 600);

                        g.DrawLine(pen, 290, 300, 310, 300);
                        g.DrawLine(pen, 300, 290, 300, 310);
                        g.DrawLine(pen, 290, 600, 300, 580);
                        g.DrawLine(pen, 310, 600, 300, 580);

                        for (int i = 0; i < 10; i++)
                        {
                            double radians = i * 10 * (Math.PI / 180);
                            int x = Convert.ToInt16(300 * Math.Cos(radians));
                            int y = Convert.ToInt16(300 * Math.Sin(radians));
                            int sx = Convert.ToInt16(280 * Math.Cos(radians));
                            int sy = Convert.ToInt16(280 * Math.Sin(radians));
                            g.DrawLine(pen, 300 + x, 300 + y, 300 + sx, 300 + sy);
                            g.DrawLine(pen, 300 - x, 300 + y, 300 - sx, 300 + sy);
                            g.DrawLine(pen, 300 + x, 300 - y, 300 + sx, 300 - sy);
                            g.DrawLine(pen, 300 - x, 300 - y, 300 - sx, 300 - sy);
                        }

                        pictureBox1.Image = bmp;
                        pictureBox1.Refresh();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("DrawWafer:\n" + ex.ToString(), "錯誤");
            }
        }

        public static bool Select_WAFER(ref DataTable oWafer,string ConnStr, string schema,string LotID)
        {
            DateTime oNow = DateTime.Now;
            string sSql = "";
            string sTemp = "";
            try
            {
                sSql += "SELECT A.LOT_ID, A.PRODSPEC_ID ,B.MTRL_ID ";
                sSql += " FROM " + schema + ".FRLOT A, " + schema + ".FRLOT_MTRL B";
                sSql += " WHERE  A.D_THESYSTEMKEY = B.D_THESYSTEMKEY AND A.LOT_ID='" + LotID + "'";
                sSql += " ORDER BY MTRL_ID WITH UR";
                oWafer = QueryTable(sSql, ConnStr, "FRLOT_MTRL");
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select_WAFER:\n" + ex.ToString(), "錯誤");
                return false;
            }
        }

        public static System.Data.DataTable QueryTable(string strSql, string m_sConnectionString, string strTableName)
        {
            string sTemp = "";
            OleDbConnection Conn = null;
            OleDbDataAdapter Ad = null;
            try
            {
                sTemp = String.Format(":QueryTable() TableName:{0}.", strTableName);
                Conn = new OleDbConnection(m_sConnectionString);
                Ad = new OleDbDataAdapter(strSql, Conn);
                System.Data.DataSet Ds = new System.Data.DataSet();
                Ds.Clear();
                Conn.Open();
                sTemp = String.Format(":Connection.Open().");
                Ad.Fill(Ds, strTableName);
                sTemp = String.Format(":OleDbDataAdapter.Fill().");
                Conn.Close();
                sTemp = String.Format(":Connection.Close().");
                Conn.Dispose();
                return Ds.Tables[strTableName];
            }
            catch (Exception ex)
            {
                //sTemp = String.Format("QueryTable() exception:{0}", ex.ToString());
                MessageBox.Show("QueryTable:\n" + ex.ToString(), "錯誤");
                return null;
            }
        }
    }
}
